#!/bin/bash
set -e

lc="$(git rev-parse --git-dir)/stone"
h=$(cat)

#echo $h >> /tmp/git_test.log

d0=$(echo $h | head -c 2)
d1=$(echo $h | head -c 4 | tail -c 2)
f=$(echo $h | tail -c 29)
df="$d0/$d1/$f"

l="$lc/$df"
if [ ! -f "$l" ]; then
    rc=$(git config --get remote.origin.url|sed 's/\(git@.*:\).*\/\([^\/]*\)/\1\2\/stone/')
    r="$rc/$df"

    #echo "lc=$lc" >> /tmp/git_test.log
    #echo "rc=$rc" >> /tmp/git_test.log
    #echo "r=$r" >> /tmp/git_test.log

    mkdir -p $(dirname $l)
    scp -O $r $l >> /tmp/git_test.log 2>&1
fi

cat "$l"
