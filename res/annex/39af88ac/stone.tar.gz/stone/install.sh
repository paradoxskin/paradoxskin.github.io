#!/bin/bash
set -ex

base=$(realpath $(dirname $0))

git config --global filter.stone.clean $base/clean.sh
git config --global filter.stone.smudge $base/smudge.sh
ln -s $base/pre-push $(git rev-parse --git-dir)/hooks
