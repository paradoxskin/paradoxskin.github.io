#!/bin/bash
set -e

tmp=$(mktemp)
cat > $tmp

h0=$(sha256sum $tmp | head -c 16)
h1=$(cat $tmp | { printf "saltprefix"; cat; printf "saltsuffix"; } | sha256sum | head -c 16)

lc="$(git rev-parse --git-dir)/stone"
h=$(printf "%s%s" $h0 $h1)

d0=$(echo $h | head -c 2)
d1=$(echo $h | head -c 4 | tail -c 2)
f=$(echo $h | tail -c 29)
df="$d0/$d1/$f"

l="$lc/$df"
if [ ! -f "$l" ]; then
    mkdir -p $(dirname $l)
    cp $tmp $l
fi

rm $tmp
echo $h
